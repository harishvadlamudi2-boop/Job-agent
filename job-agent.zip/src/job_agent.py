"""
Job Search Agent - Finds C2C/Contract TPM/TPO roles matching Harish's profile.
Sends a daily digest email with curated, filtered job listings.
"""

import os
import re
import json
import time
import logging
import smtplib
import requests
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/agent.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# ─── Profile Keywords ────────────────────────────────────────────────────────

SEARCH_QUERIES = [
    "Technical Product Manager contract C2C",
    "Technical Product Owner contract C2C",
    "Sr Technical Product Manager B2B data contract",
    "TPM MarTech data engineering contract",
    "Technical Product Owner Snowflake Salesforce contract",
    "Product Manager AI ML data platform contract",
]

MUST_HAVE_KEYWORDS = [
    "contract", "c2c", "corp to corp", "corp-to-corp", "1099",
    "independent contractor", "contract to hire"
]

EXCLUDE_KEYWORDS = [
    "w2 only", "w-2 only", "full time only", "permanent only",
    "no c2c", "no corp to corp", "citizens only",  # add as needed
]

STRONG_MATCH_SKILLS = [
    "snowflake", "azure", "salesforce", "data governance", "martech",
    "product owner", "product manager", "b2b", "ai", "ml", "llm",
    "data engineering", "databricks", "agile", "safe", "scrum",
    "crm", "erp", "privacy", "ccpa", "gdpr", "campaign", "analytics",
    "sql", "python", "power bi", "tableau"
]

# ─── Job Sources ──────────────────────────────────────────────────────────────

class AdzunaSource:
    """Adzuna has a free public API - great for contract roles."""
    BASE = "https://api.adzuna.com/v1/api/jobs/us/search/1"

    def fetch(self, query: str) -> list[dict]:
        app_id = os.getenv("ADZUNA_APP_ID", "")
        app_key = os.getenv("ADZUNA_APP_KEY", "")
        if not app_id or not app_key:
            log.warning("Adzuna credentials missing, skipping.")
            return []
        try:
            r = requests.get(self.BASE, params={
                "app_id": app_id,
                "app_key": app_key,
                "results_per_page": 20,
                "what": query,
                "where": "United States",
                "sort_by": "date",
                "max_days_old": 1,
                "content-type": "application/json"
            }, timeout=15)
            r.raise_for_status()
            results = r.json().get("results", [])
            return [self._normalize(j) for j in results]
        except Exception as e:
            log.error(f"Adzuna error: {e}")
            return []

    def _normalize(self, j: dict) -> dict:
        return {
            "title": j.get("title", ""),
            "company": j.get("company", {}).get("display_name", ""),
            "location": j.get("location", {}).get("display_name", ""),
            "description": j.get("description", ""),
            "url": j.get("redirect_url", ""),
            "posted": j.get("created", ""),
            "source": "Adzuna"
        }


class DiceSource:
    """Dice.com is the go-to for contract/C2C tech roles."""
    BASE = "https://job-search-api.svc.dhigroupinc.com/v1/dice/jobs/search"

    def fetch(self, query: str) -> list[dict]:
        try:
            r = requests.get(self.BASE, params={
                "q": query,
                "countryCode2": "US",
                "radius": 30,
                "radiusUnit": "mi",
                "page": 1,
                "pageSize": 20,
                "filters.workplaceTypes": "Remote",
                "filters.employmentType": "CONTRACTS",
                "language": "en",
            }, headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json"
            }, timeout=15)
            if r.status_code != 200:
                log.warning(f"Dice returned {r.status_code}")
                return []
            data = r.json()
            jobs = data.get("data", [])
            return [self._normalize(j) for j in jobs]
        except Exception as e:
            log.error(f"Dice error: {e}")
            return []

    def _normalize(self, j: dict) -> dict:
        return {
            "title": j.get("title", ""),
            "company": j.get("advertiserName", ""),
            "location": j.get("location", "Remote"),
            "description": j.get("jobDescription", ""),
            "url": f"https://www.dice.com/job-detail/{j.get('id', '')}",
            "posted": j.get("postedDate", ""),
            "source": "Dice"
        }


class RemoteOKSource:
    """RemoteOK has a public JSON API, good for remote contract roles."""
    BASE = "https://remoteok.com/api"

    def fetch(self, query: str) -> list[dict]:
        try:
            r = requests.get(self.BASE, headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
            r.raise_for_status()
            jobs = r.json()
            # Filter by query keywords
            q_words = query.lower().split()
            filtered = []
            for j in jobs:
                if not isinstance(j, dict) or "position" not in j:
                    continue
                text = f"{j.get('position','')} {j.get('description','')}".lower()
                if any(w in text for w in q_words[:3]):
                    filtered.append(self._normalize(j))
            return filtered[:10]
        except Exception as e:
            log.error(f"RemoteOK error: {e}")
            return []

    def _normalize(self, j: dict) -> dict:
        return {
            "title": j.get("position", ""),
            "company": j.get("company", ""),
            "location": "Remote",
            "description": j.get("description", ""),
            "url": j.get("url", ""),
            "posted": j.get("date", ""),
            "source": "RemoteOK"
        }


# ─── Filtering Engine ─────────────────────────────────────────────────────────

def score_job(job: dict) -> tuple[bool, int, list[str]]:
    """
    Returns (is_c2c_contract, relevance_score, matched_skills).
    Only returns True for confirmed C2C/contract roles.
    """
    text = f"{job['title']} {job['description']} {job.get('employment_type','')}".lower()

    # Hard filter: must be contract/C2C
    is_contract = any(kw in text for kw in MUST_HAVE_KEYWORDS)

    # Hard exclude: explicitly W2-only or FTE
    is_excluded = any(kw in text for kw in EXCLUDE_KEYWORDS)

    if not is_contract or is_excluded:
        return False, 0, []

    # Score by skill match
    matched = [s for s in STRONG_MATCH_SKILLS if s in text]
    score = len(matched)

    return True, score, matched


def filter_jobs(raw_jobs: list[dict]) -> list[dict]:
    """Deduplicate, score, and filter to C2C contract roles only."""
    seen_urls = set()
    results = []

    for job in raw_jobs:
        url = job.get("url", "")
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)

        is_c2c, score, skills = score_job(job)
        if is_c2c:
            job["score"] = score
            job["matched_skills"] = skills
            results.append(job)

    # Sort by score descending
    results.sort(key=lambda x: x["score"], reverse=True)
    log.info(f"Filtered to {len(results)} C2C contract roles.")
    return results


# ─── Email Digest ─────────────────────────────────────────────────────────────

def build_email_html(jobs: list[dict]) -> str:
    today = datetime.now().strftime("%B %d, %Y")
    if not jobs:
        body = "<p>No new C2C contract roles found today matching your profile. Check back tomorrow!</p>"
    else:
        cards = ""
        for i, j in enumerate(jobs[:25], 1):
            skills_html = "".join(
                f'<span style="background:#e8f4fd;color:#1a6fb5;padding:2px 8px;border-radius:12px;font-size:12px;margin:2px;display:inline-block">{s}</span>'
                for s in j.get("matched_skills", [])
            )
            cards += f"""
            <div style="border:1px solid #e2e8f0;border-radius:8px;padding:20px;margin:16px 0;background:#fff">
              <div style="display:flex;justify-content:space-between;align-items:start">
                <div>
                  <h3 style="margin:0 0 4px;color:#1e293b;font-size:17px">#{i}. {j['title']}</h3>
                  <p style="margin:0;color:#64748b;font-size:14px">🏢 {j['company']} &nbsp;|&nbsp; 📍 {j['location']} &nbsp;|&nbsp; 🔗 {j['source']}</p>
                </div>
                <div style="background:#dcfce7;color:#166534;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:bold;white-space:nowrap">
                  Score: {j['score']}/10
                </div>
              </div>
              <div style="margin:10px 0">{skills_html}</div>
              <p style="color:#475569;font-size:13px;margin:8px 0;line-height:1.5">
                {j['description'][:300].strip()}...
              </p>
              <a href="{j['url']}" style="display:inline-block;background:#2563eb;color:#fff;padding:8px 18px;border-radius:6px;text-decoration:none;font-size:13px;font-weight:600;margin-top:6px">
                View & Apply →
              </a>
            </div>"""
        body = cards

    return f"""
    <html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f8fafc;margin:0;padding:20px">
      <div style="max-width:720px;margin:0 auto">
        <div style="background:linear-gradient(135deg,#1e3a5f,#2563eb);padding:30px;border-radius:12px;color:#fff;margin-bottom:24px">
          <h1 style="margin:0;font-size:24px">🤖 Daily Job Digest</h1>
          <p style="margin:6px 0 0;opacity:0.85">C2C Contract Roles · Technical Product Manager / Owner · {today}</p>
          <p style="margin:6px 0 0;opacity:0.7;font-size:13px">Filtered for: C2C/Corp-to-Corp only · No W2 · No FTE</p>
        </div>
        <div style="background:#fef9c3;border:1px solid #fde68a;border-radius:8px;padding:14px;margin-bottom:20px;font-size:13px;color:#92400e">
          <strong>⚠️ Important:</strong> {len(jobs)} roles found today. Roles are ranked by skill match score. Click "View & Apply" to review and submit your application directly on the job board.
        </div>
        {body}
        <p style="text-align:center;color:#94a3b8;font-size:12px;margin-top:30px">
          Job Agent · Searches: Dice, Adzuna, RemoteOK · Runs daily at 8AM PST
        </p>
      </div>
    </body></html>"""


def send_email(jobs: list[dict]):
    sender = os.environ["EMAIL_FROM"]
    recipient = os.environ["EMAIL_TO"]
    password = os.environ["EMAIL_PASSWORD"]
    smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"🤖 Job Digest: {len(jobs)} C2C Contract Roles Found – {datetime.now().strftime('%b %d')}"
    msg["From"] = sender
    msg["To"] = recipient
    msg.attach(MIMEText(build_email_html(jobs), "html"))

    with smtplib.SMTP(smtp_host, smtp_port) as server:
        server.starttls()
        server.login(sender, password)
        server.sendmail(sender, recipient, msg.as_string())
    log.info(f"Email sent to {recipient} with {len(jobs)} jobs.")


# ─── Save Results ─────────────────────────────────────────────────────────────

def save_results(jobs: list[dict]):
    os.makedirs("logs", exist_ok=True)
    fname = f"logs/jobs_{datetime.now().strftime('%Y%m%d')}.json"
    with open(fname, "w") as f:
        json.dump(jobs, f, indent=2)
    log.info(f"Saved {len(jobs)} jobs to {fname}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def run():
    log.info("=" * 60)
    log.info("Job Agent starting...")

    sources = [DiceSource(), AdzunaSource(), RemoteOKSource()]
    all_raw = []

    for query in SEARCH_QUERIES:
        log.info(f"Searching: '{query}'")
        for source in sources:
            jobs = source.fetch(query)
            log.info(f"  {source.__class__.__name__}: {len(jobs)} raw results")
            all_raw.extend(jobs)
            time.sleep(1)  # polite delay

    log.info(f"Total raw jobs collected: {len(all_raw)}")
    filtered = filter_jobs(all_raw)

    save_results(filtered)

    if os.getenv("EMAIL_FROM"):
        send_email(filtered)
    else:
        log.warning("EMAIL_FROM not set — skipping email. Results saved to logs/")

    log.info(f"Done. {len(filtered)} C2C contract roles found today.")


if __name__ == "__main__":
    run()
