# 🤖 TPM/TPO Job Search Agent
**Automated daily C2C contract job finder for Technical Product Manager / Owner roles**

Built for: Harish Vadlamudi — Senior TPM with 10+ years in MarTech, Data Engineering, AI/ML, and B2B platforms.

---

## What This Agent Does

Every weekday at **8:00 AM PST**, this GitHub Actions agent:

1. **Searches** Dice, Adzuna, and RemoteOK for TPM/TPO roles
2. **Filters** to **C2C/Corp-to-Corp contract only** — W2 and full-time roles are excluded
3. **Scores** each role by how many of your skills match (Snowflake, Azure, Salesforce, AI/ML, etc.)
4. **Emails** you a ranked digest with direct apply links

> ⚠️ **Why not auto-apply?** Most job boards (LinkedIn, Dice) prohibit automated form submission in their ToS, and auto-applying with a generic submission gets your resume filtered out. This agent sends you curated, ranked leads — you apply in one click with a tailored message.

---

## Job Sources

| Source | Why | Contract Filter |
|--------|-----|-----------------|
| **Dice.com** | Best for C2C tech contracts in the US | `employmentType=CONTRACTS` |
| **Adzuna** | Free public API, broad coverage | Keyword-filtered |
| **RemoteOK** | Remote-first, public JSON API | Keyword-filtered |

---

## Setup Instructions

### Step 1: Fork/Clone This Repo

```bash
git clone https://github.com/YOUR_USERNAME/job-agent.git
cd job-agent
```

### Step 2: Add GitHub Secrets

Go to your repo → **Settings → Secrets and variables → Actions → New repository secret**

Add these secrets:

| Secret Name | Value |
|-------------|-------|
| `EMAIL_FROM` | Your Gmail address |
| `EMAIL_TO` | `harishvadlamudi2@gmail.com` |
| `EMAIL_PASSWORD` | Gmail App Password (see below) |
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `ADZUNA_APP_ID` | From https://developer.adzuna.com/ (free) |
| `ADZUNA_APP_KEY` | From https://developer.adzuna.com/ (free) |

**Getting a Gmail App Password:**
1. Enable 2FA on your Google account
2. Go to https://myaccount.google.com/apppasswords
3. Create a new app password → copy the 16-character code
4. Use that as `EMAIL_PASSWORD`

### Step 3: Get Free Adzuna API Keys

1. Register at https://developer.adzuna.com/
2. Create an app → get `App ID` and `App Key`
3. Free tier: 250 requests/month (plenty for daily runs)

### Step 4: Test Locally

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your real credentials
python src/job_agent.py
```

### Step 5: Enable GitHub Actions

1. Push to GitHub
2. Go to **Actions** tab → enable workflows
3. Click **"Daily Job Search Agent"** → **"Run workflow"** to test manually

---

## Customization

### Adjust Search Queries
Edit `SEARCH_QUERIES` in `src/job_agent.py`:
```python
SEARCH_QUERIES = [
    "Technical Product Manager contract C2C",
    "Technical Product Owner Snowflake contract",
    # Add more specific queries...
]
```

### Add/Remove Skills to Match
Edit `STRONG_MATCH_SKILLS` to match your evolving profile.

### Change Schedule
Edit `.github/workflows/daily_job_search.yml`:
```yaml
- cron: "0 16 * * 1-5"  # 8AM PST weekdays
```

---

## Output

- **Daily email digest** with ranked job listings
- **JSON log files** saved to `logs/jobs_YYYYMMDD.json`
- **GitHub Actions artifacts** retained for 30 days

---

## Profile: Harish Vadlamudi
**Target roles:** Sr. Technical Product Manager / Technical Product Owner
**Contract type:** C2C / Corp-to-Corp ONLY
**Key skills:** Snowflake, Azure, Salesforce, DataOps, MarTech, AI/ML, LLM, CCPA/GDPR, B2B Data
**Location:** Everett, WA (open to remote)
